# reset-cache

The transform cache was reset.

`react-native start --reset-cache`是启动Metro时清除缓存的命令，比方说新增一个package的时候。
