# nox夜神模拟器

<https://www.yeshen.com/faqs/ByJvFeXeZ> <https://www.yeshen.com/faqs/HkjT_gmeb> <https://blog.csdn.net/qq_53002263/article/details/125610113>

下载地址和安装教程见：<https://acnp6tmmnnfg.feishu.cn/wiki/IllGwGe5Lib2xykZYMlcZ8nqn2d>
