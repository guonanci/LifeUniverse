<https://console.firebase.google.com/project/zejingit/settings/general/android:com.zejingit.xllsctb?hl=zh-cn>

<https://console.firebase.google.com/project/zejingit/settings/general/android:com.zejingit.xllsctb?hl=zh-cn>

<https://github.com/zo0r/react-native-push-notification>

<https://cloud.tencent.com/developer/article/2389754>

app消息推送功能的话，还需要研究，还没完全研究清楚整体流程和其中的细节。
