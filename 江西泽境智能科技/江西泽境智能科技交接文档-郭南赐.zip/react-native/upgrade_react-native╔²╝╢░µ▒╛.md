<https://react-native-community.github.io/upgrade-helper/?from=0.74.1&to=0.75.0-rc.5>
