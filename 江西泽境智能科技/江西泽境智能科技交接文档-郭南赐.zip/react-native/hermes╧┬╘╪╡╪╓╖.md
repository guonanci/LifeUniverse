# hermes-android-0.74.1-debug.aar下载很慢
可以通过复制下载地址到浏览器即可秒速下载完，不要在Android studio里下载。

react-android-0.74.1-debug.aar似乎下载比较快。

https://repo.maven.apache.org/maven2/com/facebook/react/react-android/0.74.1/react-android-0.74.1-release.aar

https://repo.maven.apache.org/maven2/com/facebook/react/react-android/0.74.1/react-android-0.74.1-debug.aar

https://repo.maven.apache.org/maven2/com/facebook/react/hermes-android/0.74.1/hermes-android-0.74.1-debug.aar

https://repo.maven.apache.org/maven2/com/facebook/react/hermes-android/0.74.1/hermes-android-0.74.1-release.aar
